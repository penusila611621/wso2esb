/**
 * 
 */
package com.aegbt.gtr.propertyDataService.service;

/**
 * @author gavvaru
 *
 */
public class PropertyDataServiceTest {

}
