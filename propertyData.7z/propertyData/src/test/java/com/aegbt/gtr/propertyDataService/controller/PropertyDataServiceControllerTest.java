package com.aegbt.gtr.propertyDataService.controller;

/**
 * 
 */
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.aegbt.gtr.propertyDataService.config.AegtrWebControllerTest;

/**
 * @author gavvaru
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
public class PropertyDataServiceControllerTest extends AegtrWebControllerTest{

	private static final String TRANID = "b9b682e0-cded-11e5-a108-1b2d890f3c19"; 
	private static final String LOGLEVEL = "info";
	
	/**
	 * Status 200 check
	 * @throws Exception
	 */
	@Test
	public void test_propertyDataService_withDataSetAndKey_ShouldReturn200() throws Exception {
		mockMvc.perform(get("/propertydata/v1").param("dataset", "airport").param("key","AAA111").header("tranid", TRANID).header("loglevel", LOGLEVEL)).andExpect(status().is(200));
	}
	
	/**
	 * Status 200 check
	 * @throws Exception
	 */
	@Test
	public void test_propertyDataService_withDataSet_ShouldReturn200() throws Exception {
		mockMvc.perform(get("/propertydata/v1").param("dataset", "airport").header("tranid", TRANID).header("loglevel", LOGLEVEL)).andExpect(status().is(200));
	}
	
	/**
	 * Status 406 check
	 * @throws Exception
	 */
	@Test
	public void test_propertyDataService_withNoDataSet_ShouldReturn400() throws Exception {
		mockMvc.perform(get("/propertydata/v1").header("tranid", TRANID).header("loglevel", LOGLEVEL)).andExpect(status().is(400));
	}
	
	
}
