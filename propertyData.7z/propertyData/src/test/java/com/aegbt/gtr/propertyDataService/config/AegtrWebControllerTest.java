/**
 * 
 */
package com.aegbt.gtr.propertyDataService.config;

import org.junit.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;

import com.aegbt.gtr.timestamputility.TimestampConverter;

/**
 * @author gavvaru
 *
 */
@SpringApplicationConfiguration(classes = AegtrWebController.class)
@WebAppConfiguration
public class AegtrWebControllerTest {
	
	public MockMvc mockMvc;

	@Autowired
	private WebApplicationContext webApplicationContext;

	@Before
	public void setup() {
		TimestampConverter.loadResourceBundle();
		mockMvc = MockMvcBuilders.webAppContextSetup(webApplicationContext)
				.build();
	}

}
