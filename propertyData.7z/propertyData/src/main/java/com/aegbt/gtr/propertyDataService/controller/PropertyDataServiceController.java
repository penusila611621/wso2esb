/**
 * 
 */
package com.aegbt.gtr.propertyDataService.controller;


import java.util.Map;



import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.aegbt.gtr.helperutility.bean.ErrorMessageBean;
import com.aegbt.gtr.helperutility.constants.GtrConstants;
import com.aegbt.gtr.helperutility.helper.AuditDtoHelper;
import com.aegbt.gtr.helperutility.helper.XmlParsing;
import com.aegbt.gtr.helperutility.service.ErrorMessageService;
import com.aegbt.gtr.propertyDataService.exception.InvalidPropertyKeyException;
import com.aegbt.gtr.propertyDataService.exception.InvalidPropertyListException;
import com.aegbt.gtr.propertyDataService.reponse.PropertyDataError;
import com.aegbt.gtr.propertyDataService.reponse.PropertyDataServiceResponse;
import com.aegbt.gtr.propertyDataService.service.PropertyDataService;

/**
 * Request handler class.
 * @author gavvaru
 *
 */
@RestController
public class PropertyDataServiceController {
	
	@Autowired
	private ErrorMessageService errorConfigService;
	
	@Autowired
	private PropertyDataService propertyDataService;
	
	@Autowired
	private AuditDtoHelper auditDtoHelper;
	
	@Autowired
	private XmlParsing xmlParsing;
	
	
	@Value("${processDataService}")
	private String processDataServiceAuditData;
	
	private String successErrMessage = "Property Data Service Success";
	private String failureErrMessage = "Property Data Service Fail";
	
	/**
	 * 
	 * @return
	 */
	@RequestMapping(value = "/propertydata/v1",method = RequestMethod.GET, produces = "application/xml")
	public ResponseEntity getPropertyData(@RequestParam("dataset") String dataset, @RequestParam( value="key", required=false) String key,@RequestHeader String loglevel, @RequestHeader String tranid,@RequestHeader String processor,@RequestHeader String responseFormat){
		long startTime = System.currentTimeMillis();
		long endTime;
		String result="";
		String T_Success="Success";
		String T_False = "Fail";
		PropertyDataServiceResponse propertyDataServiceResponse = null;
		try{
			if(null != key){
				if(!StringUtils.isBlank(responseFormat) && responseFormat.equalsIgnoreCase("xml"))
					result = propertyDataService.decodeValueForXml(dataset, key);
				else
					result = propertyDataService.decodeValueForJson(dataset, key);
			}			
			else{
				if(!StringUtils.isBlank(responseFormat) && responseFormat.equalsIgnoreCase("xml"))
					result = propertyDataService.getPropertyListForXml(dataset);
				else
					result = propertyDataService.getPropertyListForJson(dataset);
			}
		}catch(InvalidPropertyListException e){
			System.out.println("InvalidPropertyListException********************startTime"+startTime);
			endTime = System.currentTimeMillis();
			System.out.println("InvalidPropertyListException********************endTime"+endTime);
			Map<String, ErrorMessageBean> errorConfigBeanMap = errorConfigService.getCachedErrorData(processor, "PropertyService");
			PropertyDataError propertyDataError = new PropertyDataError(errorConfigBeanMap.get("GTR204").getErrorcode(),errorConfigBeanMap.get("GTR204").getErrordesc());
			propertyDataServiceResponse = new PropertyDataServiceResponse(GtrConstants.TRANSACTION_SUCCESS_FALSE, propertyDataError);
			auditDtoHelper.constructAuditDto(startTime, endTime, propertyDataServiceResponse, PropertyDataServiceResponse.class, processDataServiceAuditData, loglevel, "", tranid, T_False, failureErrMessage, "");
			return new ResponseEntity(propertyDataServiceResponse,HttpStatus.OK);
		}catch(InvalidPropertyKeyException e){
			System.out.println("InvalidPropertyKeyException********************startTime"+startTime);
			endTime = System.currentTimeMillis();
			System.out.println("InvalidPropertyKeyException********************endTime"+endTime);
			Map<String, ErrorMessageBean> errorConfigBeanMap = errorConfigService.getCachedErrorData(processor, "PropertyService");
			PropertyDataError propertyDataError = new PropertyDataError(errorConfigBeanMap.get("GTR205").getErrorcode(),errorConfigBeanMap.get("GTR205").getErrordesc());
			propertyDataServiceResponse = new PropertyDataServiceResponse(GtrConstants.TRANSACTION_SUCCESS_FALSE, propertyDataError);
			auditDtoHelper.constructAuditDto(startTime, endTime, propertyDataServiceResponse, PropertyDataServiceResponse.class, processDataServiceAuditData, loglevel, "", tranid, T_False, failureErrMessage, "");
			return new ResponseEntity(propertyDataServiceResponse,HttpStatus.OK);
		}catch(Exception e){
			System.out.println("Exception********************startTime"+startTime);
			endTime = System.currentTimeMillis();
			System.out.println("Exception********************endTime"+endTime);
			Map<String, ErrorMessageBean> errorConfigBeanMap = errorConfigService.getCachedErrorData(processor, "PropertyService");
			PropertyDataError propertyDataError = new PropertyDataError(errorConfigBeanMap.get("GTR203").getErrorcode(),errorConfigBeanMap.get("GTR203").getErrordesc());
			propertyDataServiceResponse = new PropertyDataServiceResponse(GtrConstants.TRANSACTION_SUCCESS_FALSE, propertyDataError);
			auditDtoHelper.constructAuditDto(startTime, endTime, propertyDataServiceResponse, PropertyDataServiceResponse.class, processDataServiceAuditData, loglevel,"", tranid, T_False, failureErrMessage, "");
			return new ResponseEntity(propertyDataServiceResponse,HttpStatus.INTERNAL_SERVER_ERROR);
		}
		endTime = System.currentTimeMillis();
		System.out.println("Success********************startTime"+startTime);
		System.out.println("Success********************endTime"+endTime);
		propertyDataServiceResponse = new PropertyDataServiceResponse(GtrConstants.TRANSACTION_SUCCESS_TRUE, result);
		if(null != key){
			auditDtoHelper.constructAuditDto(startTime, endTime, propertyDataServiceResponse, PropertyDataServiceResponse.class, processDataServiceAuditData, loglevel,"", tranid, T_Success, successErrMessage, "");
			return new ResponseEntity(propertyDataServiceResponse.toString(),HttpStatus.OK);
		}		    
		else{
			auditDtoHelper.constructAuditDtoForSegments(startTime, endTime, propertyDataServiceResponse.toString(), processDataServiceAuditData, loglevel, "", tranid,T_Success , successErrMessage, "");
			return new ResponseEntity(propertyDataServiceResponse.toString(),HttpStatus.OK);
		}
	}
}
