/**
 * 
 */
package com.aegbt.gtr.propertyDataService.bean;

import java.io.Serializable;

import org.springframework.cassandra.core.PrimaryKeyType;
import org.springframework.data.cassandra.mapping.PrimaryKeyColumn;
import org.springframework.data.cassandra.mapping.Table;

/**
 * @author gavvaru
 *
 */
@Table(value = "propertydata")
public class PropertyData implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@PrimaryKeyColumn(ordinal=0, type=PrimaryKeyType.PARTITIONED)
	private String propertyList;
	@PrimaryKeyColumn(ordinal=0, type=PrimaryKeyType.CLUSTERED)
	private String propertyKey;
	private String propertyValue;
	
	public String getPropertyList() {
		return propertyList;
	}
	public void setPropertyList(String propertyList) {
		this.propertyList = propertyList;
	}
	public String getPropertyKey() {
		return propertyKey;
	}
	public void setPropertyKey(String propertyKey) {
		this.propertyKey = propertyKey;
	}
	public String getPropertyValue() {
		return propertyValue;
	}
	public void setPropertyValue(String propertyValue) {
		this.propertyValue = propertyValue;
	}

}
