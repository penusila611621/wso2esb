/**
 * 
 */
package com.aegbt.gtr.propertyDataService.dao.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.aegbt.gtr.propertyDataService.bean.PropertyData;
import com.aegbt.gtr.propertyDataService.dao.PropertyDataDao;
import com.aegbt.gtr.propertyDataService.repository.PropertyDataRepository;

/**
 * @author gavvaru
 *
 */
@Component
public class PropertyDataDaoImpl implements PropertyDataDao{
	
	@Autowired
	private PropertyDataRepository propertyDataRepository;

	@Override
	public List<PropertyData> getProperyList() throws Exception {
		// TODO Auto-generated method stub
		return (List<PropertyData>) propertyDataRepository.findAll();
	}

	@Override
	public PropertyData getPropertyObject(String propertyList,
			String propertyKey) throws Exception {
		// TODO Auto-generated method stub
		return propertyDataRepository.getPropertyByListAndKey(propertyList, propertyKey);
	}

	@Override
	public List<PropertyData> getPropertyListByName(String propertyList)
			throws Exception {
		// TODO Auto-generated method stub
		return propertyDataRepository.getPropertyByList(propertyList);
	}

}
