/**
 * 
 */
package com.aegbt.gtr.propertyDataService.service;

import java.util.Map;

import com.aegbt.gtr.propertyDataService.exception.InvalidPropertyKeyException;
import com.aegbt.gtr.propertyDataService.exception.InvalidPropertyListException;

/**
 * @author gavvaru
 *
 */
public interface PropertyDataService {

	/*
	 *  To fetch value for the given propertyList, key and number.
	 */
	public String decodeValueForXml(String propertyListName, String propertyKeyName) throws InvalidPropertyListException,InvalidPropertyKeyException,Exception;
	
	public String decodeValueForJson(String propertyListName, String propertyKeyName) throws InvalidPropertyListException,InvalidPropertyKeyException,Exception;
	
	/*
	 * To return the map object for the given propertyListName.
	 */
	public Map<String, String> getPropertyKeyObject(String propertyListName) throws InvalidPropertyListException,Exception;
	
	
	public String getPropertyListForXml(String propertyListName) throws InvalidPropertyListException,Exception;
	
	public String getPropertyListForJson(String propertyListName) throws InvalidPropertyListException,Exception;
	
}
