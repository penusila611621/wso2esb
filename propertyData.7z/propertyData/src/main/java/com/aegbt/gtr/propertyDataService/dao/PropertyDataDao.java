/**
 * 
 */
package com.aegbt.gtr.propertyDataService.dao;

import java.util.List;

import com.aegbt.gtr.propertyDataService.bean.PropertyData;

/**
 * @author gavvaru
 *
 */
public interface PropertyDataDao {

	public List<PropertyData> getProperyList() throws Exception;

	public PropertyData getPropertyObject(String propertyList,
			String propertyKey) throws Exception;

	public List<PropertyData> getPropertyListByName(String propertyList)
			throws Exception;

}
