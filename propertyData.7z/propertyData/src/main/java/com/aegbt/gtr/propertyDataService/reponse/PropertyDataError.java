/**
 * 
 */
package com.aegbt.gtr.propertyDataService.reponse;

import javax.xml.bind.annotation.XmlElement;

/**
 * @author gavvaru
 *
 */
public class PropertyDataError {

	private String errorCode;
	private String errorMessage;
	
	public PropertyDataError(String errorCode, String errorMessage) {
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;
	}
	
	public PropertyDataError() {
	}

	@XmlElement(name = "ErrorCode")
	public String getErrorCode() {
		return errorCode;
	}
	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	@XmlElement(name = "ErrorMessage")
	public String getErrorMessage() {
		return errorMessage;
	}
	public void setErrorMessage(String errorMessage) {
		this.errorMessage = errorMessage;
	}
	
}
