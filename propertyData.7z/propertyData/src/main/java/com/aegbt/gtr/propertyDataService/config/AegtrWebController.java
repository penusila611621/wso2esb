package com.aegbt.gtr.propertyDataService.config;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.context.web.SpringBootServletInitializer;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.EnableScheduling;

import com.aegbt.gtr.timestamputility.TimestampConverter;

/**
 * @author gavvaru
 *
 */
@SpringBootApplication
@EnableScheduling
@ComponentScan("com.aegbt.gtr.propertyDataService,com.aegbt.gtr.helperutility")
public class AegtrWebController extends SpringBootServletInitializer {

	public static void main(String[] args) {
		SpringApplication.run(AegtrWebController.class, args);
	}

	@Override
	protected SpringApplicationBuilder configure(
			SpringApplicationBuilder application) {
		TimestampConverter.loadResourceBundle();
		return application.sources(AegtrWebController.class);
	}

}
