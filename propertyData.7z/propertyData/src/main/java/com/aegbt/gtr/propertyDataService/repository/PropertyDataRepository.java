/**
 * 
 */
package com.aegbt.gtr.propertyDataService.repository;

import java.util.List;

import org.springframework.data.cassandra.repository.CassandraRepository;
import org.springframework.data.cassandra.repository.Query;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.aegbt.gtr.propertyDataService.bean.PropertyData;

/**
 * Repository interface for property table.
 * @author gavvaru
 *
 */
@Component
public interface PropertyDataRepository extends CassandraRepository<PropertyData>{
	
	@Query("SELECT * FROM propertydata WHERE propertylist=?0 AND propertykey=?1")
	public PropertyData getPropertyByListAndKey(String propertyList, String propertyKey);
	
	@Query("SELECT * FROM propertydata WHERE propertylist=?0")
	public List<PropertyData> getPropertyByList(String propertyList);
	
}
