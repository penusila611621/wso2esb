/**
 * 
 */
package com.aegbt.gtr.propertyDataService.reponse;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * @author gavvaru
 *
 */
@XmlRootElement(name = "GetPropertyDataResponse")
@XmlType(propOrder={"success", "propertyDataError","propertyValue"})
public class PropertyDataServiceResponse {
	
	private String success;
	private PropertyDataError propertyDataError;
	private String propertyValue;
	
	public PropertyDataServiceResponse(String status,PropertyDataError propertyDataError){
		this.success = status;
		this.propertyDataError = propertyDataError;
	}
	
	public PropertyDataServiceResponse(){
		
	}
	
	public PropertyDataServiceResponse(String status,String propertyValue){
		this.success = status;
		this.propertyValue = propertyValue;
	}
	
	@XmlElement(name="Success")
	public String getSuccess() {
		return success;
	}
	public void setSuccess(String success) {
		this.success = success;
	}
	@XmlElement(name = "PropertyDataError")
	public PropertyDataError getPropertyDataError() {
		return propertyDataError;
	}
	public void setPropertyDataError(PropertyDataError propertyDataError) {
		this.propertyDataError = propertyDataError;
	}
	public String getPropertyValue() {
		return propertyValue;
	}
	@XmlElement(name = "PropertyValue")
	public void setPropertyValue(String propertyValue) {
		this.propertyValue = propertyValue;
	}

	@Override
	public String toString() {
		StringBuilder respo = new StringBuilder();
		respo.append("<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>");
		respo.append(propertyValue);		
		return respo.toString();
	}
	
	
	
	
	
	

}
