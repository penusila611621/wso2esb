/*package com.aegbt.gtr.propertyDataService.log;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.aegbt.gtr.propertyDataService.constants.PropertyDataConstants;


*//**
 * AspectMonitor class is a Aspect class used for logging.
 * 
 * @author gavvaru
 *//*
@Aspect
@Component
public class AspectMonitor {

	private final Logger logger = LoggerFactory.getLogger("INFO");

	*//**
	 * logServiceBefore method logs at the start of each public method. 
	 * 
	 * @param joinPoint
	 * @return Nothing
	 * 
	 *//*
	@Before("execution(public * com.aegbt.gtr.propertyDataService..*.*.*(..))")
	public void logServiceBefore(JoinPoint joinPoint) {
		logger.info(PropertyDataConstants.LOG_BEFOREMETHODEXECUTION_MESSAGE+joinPoint.getSignature());
	}

	*//**
	 * logServiceAfter method logs at the exit of each public method. 
	 * 
	 * @param joinPoint
	 * @return Nothing
	 * 
	 *//*
	@After("execution(public * com.aegbt.gtr.propertyDataService..*.*.*(..))")
	public void logServiceAfter(JoinPoint joinPoint) {
		logger.info(PropertyDataConstants.LOG_AFTERMETHODEXECUTION_MESSAGE+joinPoint.getSignature());
	}

	*//**
	 * logServiceThrowing method logs when an exception is thrown. 
	 * 
	 * @param e
	 * @return Nothing
	 * 
	 *//*
	@AfterThrowing(pointcut = "execution(public * com.aegbt.gtr.propertyDataService..*.*.*(..))", throwing = "e")
	public void logServiceThrowing(Exception e) {
		logger.error(PropertyDataConstants.LOG_EXCEPTION_MESSAGE+e.toString());
	}

}

*/