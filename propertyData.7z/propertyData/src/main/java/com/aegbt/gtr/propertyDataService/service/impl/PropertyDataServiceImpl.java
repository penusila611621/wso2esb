/**
 * 
 */
package com.aegbt.gtr.propertyDataService.service.impl;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.aegbt.gtr.propertyDataService.bean.PropertyData;
import com.aegbt.gtr.propertyDataService.constants.PropertyDataConstants;
import com.aegbt.gtr.propertyDataService.dao.PropertyDataDao;
import com.aegbt.gtr.propertyDataService.exception.InvalidPropertyKeyException;
import com.aegbt.gtr.propertyDataService.exception.InvalidPropertyListException;
import com.aegbt.gtr.propertyDataService.service.PropertyDataService;

/**
 * @author gavvaru
 *
 */
@Service
public class PropertyDataServiceImpl implements PropertyDataService{
	private final Logger logger = LoggerFactory.getLogger(this.getClass());
	@Autowired
	private PropertyDataDao propertyDataDao;
	
	private Map<String, Map<String, String>> propertyMap = null;
	
	
	@Scheduled(fixedRate = PropertyDataConstants.schdulerTime)
	private void initiateMap() throws Exception {
		logger.info("Schduler calling for "+PropertyDataConstants.schdulerTime);
		propertyMap = null;
		propertyMap = new HashMap<String, Map<String, String>>(
				constructMapForPropertyData());
	}
	
	private Map<String, Map<String, String>> constructMapForPropertyData() throws Exception {
		Map<String, Map<String, String>> propertyMap = new HashMap<String, Map<String, String>>();
		Map<String, String> propertyKeyMap = null;
		String propertyValue = null;
		List<PropertyData> propertyList = propertyDataDao.getProperyList();
		for (PropertyData property : propertyList) {
			if (propertyMap.containsKey(property.getPropertyList())) {
				propertyValue = property.getPropertyValue();
				propertyMap.get(property.getPropertyList()).put(
						property.getPropertyKey(), propertyValue);
			} else {
				propertyKeyMap = new HashMap<String, String>();
				propertyValue = property.getPropertyValue();
				propertyKeyMap.put(property.getPropertyKey(),
						propertyValue);
				propertyMap.put(property.getPropertyList(), propertyKeyMap);
			}
		}
		return propertyMap;
	}

	@Override
	public String decodeValueForXml(String propertyListName, String propertyKeyName)
			throws InvalidPropertyListException,InvalidPropertyKeyException,Exception  {
		propertyListName = convertToLowerCase(propertyListName);
		propertyKeyName = convertToUpperCase(propertyKeyName);
		StringBuilder response = new StringBuilder();
		response.append("<PropertyList DataSet='"+propertyListName+"'>");
		// TODO Auto-generated method stub
		if (null == propertyMap) {
			logger.info("Querying DB for the search= "+propertyListName+":"+propertyKeyName);
			PropertyData property = propertyDataDao.getPropertyObject(convertToLowerCase(propertyListName),
					propertyKeyName);
			if (null != property) {
				response.append("<Property key='"+property.getPropertyKey()+"'>"+property.getPropertyValue()+"</Property>");
				response.append("</PropertyList>");
				return response.toString();
			} else {
				throw new InvalidPropertyListException(PropertyDataConstants.noListFound);
			}
		}
		logger.info("Querying cache for the search= "+propertyListName+":"+propertyKeyName);
		Map<String, String> propertyKeyMap = propertyMap.get(propertyListName);
		if (null == propertyKeyMap) {
			throw new InvalidPropertyListException(PropertyDataConstants.noListFound);
		}
		String propertyKeyValue = propertyKeyMap.get(propertyKeyName);
		if (null == propertyKeyValue) {
			throw new InvalidPropertyKeyException(PropertyDataConstants.noKeyFound);
		}
		response.append("<Property key='"+propertyKeyName+"'>"+propertyKeyValue+"</Property>");
		response.append("</PropertyList>");
		return response.toString();
	}
	
	@Override
	public String decodeValueForJson(String propertyListName, String propertyKeyName)
			throws InvalidPropertyListException,InvalidPropertyKeyException,Exception  {
		propertyListName = convertToLowerCase(propertyListName);
		propertyKeyName = convertToUpperCase(propertyKeyName);
		StringBuilder response = new StringBuilder();
		response.append("<PropertyList><"+propertyListName+">");
		// TODO Auto-generated method stub
		if (null == propertyMap) {
			logger.info("Querying DB for the search= "+propertyListName+":"+propertyKeyName);
			PropertyData property = propertyDataDao.getPropertyObject(convertToLowerCase(propertyListName),
					propertyKeyName);
			if (null != property) {		
				response.append("<"+property.getPropertyKey()+">"+property.getPropertyValue()+"</"+property.getPropertyKey()+">");
				response.append("</"+propertyListName+"></PropertyList>");
				return response.toString();
			} else {
				throw new InvalidPropertyListException(PropertyDataConstants.noListFound);
			}
		}
		logger.info("Querying cache for the search= "+propertyListName+":"+propertyKeyName);
		Map<String, String> propertyKeyMap = propertyMap.get(propertyListName);
		if (null == propertyKeyMap) {
			throw new InvalidPropertyListException(PropertyDataConstants.noListFound);
		}
		String propertyKeyValue = propertyKeyMap.get(propertyKeyName);
		if (null == propertyKeyValue) {
			throw new InvalidPropertyKeyException(PropertyDataConstants.noKeyFound);
		}
		response.append("<"+propertyKeyName+">"+propertyKeyValue+"</"+propertyKeyName+">");
		response.append("</"+propertyListName+"></PropertyList>");
		return response.toString();
	}

	@Override
	public Map<String, String> getPropertyKeyObject(String propertyListName)
			throws InvalidPropertyListException,Exception {
		// TODO Auto-generated method stub
		propertyListName = convertToLowerCase(propertyListName);
		if (null == propertyMap) {
			logger.info("Querying DB for the search= "+propertyListName);
			Map<String, String> propertyMap = new HashMap<String, String>();
			String propertyValyeArr = null;
			List<PropertyData> propertyList = propertyDataDao
					.getPropertyListByName(propertyListName);
			if (propertyList.size() != 0) {
				for (PropertyData property : propertyList) {
					propertyValyeArr = property.getPropertyValue();
					propertyMap.put(property.getPropertyKey(),
							propertyValyeArr);
				}
			} else {
				throw new InvalidPropertyListException(PropertyDataConstants.noListFound);
			}
			return propertyMap;
		}
		logger.info("Querying cache for the search= "+propertyListName);
		Map<String, String> propertyKeyMap = propertyMap.get(propertyListName);
		if (null != propertyKeyMap) {
			return propertyKeyMap;
		} else {
			throw new InvalidPropertyListException(PropertyDataConstants.noListFound);
		}
	}
	@Override
	public String getPropertyListForXml(String propertyListName) throws InvalidPropertyListException,Exception{
		StringBuilder response = new StringBuilder();
		propertyListName = convertToLowerCase(propertyListName);
		response.append("<PropertyList DataSet='"+propertyListName+"'>");
		if (null == propertyMap) {
			logger.info("Querying DB for the search= "+propertyListName);
			List<PropertyData> propertyList = propertyDataDao
					.getPropertyListByName(propertyListName);
			if (propertyList.size() != 0) {
				for (PropertyData property : propertyList) {
					response.append("<Property key='"+property.getPropertyKey()+"'>"+property.getPropertyValue()+"</Property>");
				}
		    response.append("</PropertyList>");
			}else {
				throw new InvalidPropertyListException(PropertyDataConstants.noListFound);
			}
			return response.toString();
		}
		logger.info("Querying cache for the search= "+propertyListName);
		Map<String, String> propertyKeyMap = propertyMap.get(propertyListName);
		if (null != propertyKeyMap) {
			Iterator it = propertyKeyMap.entrySet().iterator();
			 while (it.hasNext()) {
			        Map.Entry pair = (Map.Entry)it.next();
			        response.append("<Property key='"+pair.getKey()+"'>"+pair.getValue()+"</Property>");
			 }
			 response.append("</PropertyList>");
		} else {
			throw new InvalidPropertyListException(PropertyDataConstants.noListFound);
		}
		return response.toString();
		
	}
	
	@Override
	public String getPropertyListForJson(String propertyListName) throws InvalidPropertyListException,Exception{
		StringBuilder response = new StringBuilder();
		propertyListName = convertToLowerCase(propertyListName);
		response.append("<PropertyList><"+propertyListName+">");
		if (null == propertyMap) {
			logger.info("Querying DB for the search= "+propertyListName);
			List<PropertyData> propertyList = propertyDataDao
					.getPropertyListByName(propertyListName);
			if (propertyList.size() != 0) {
				for (PropertyData property : propertyList) {
					response.append("<"+property.getPropertyKey()+">"+property.getPropertyValue()+"<"+property.getPropertyKey()+">");
				}
		    response.append("</"+propertyListName+"></PropertyList>");
			}else {
				throw new InvalidPropertyListException(PropertyDataConstants.noListFound);
			}
			return response.toString();
		}
		logger.info("Querying cache for the search= "+propertyListName);
		Map<String, String> propertyKeyMap = propertyMap.get(propertyListName);
		if (null != propertyKeyMap) {
			Iterator it = propertyKeyMap.entrySet().iterator();
			 while (it.hasNext()) {
			        Map.Entry pair = (Map.Entry)it.next();
			        response.append("<"+pair.getKey()+">"+pair.getValue()+"</"+pair.getKey()+">");
			 }
			    response.append("</"+propertyListName+"></PropertyList>");
		} else {
			throw new InvalidPropertyListException(PropertyDataConstants.noListFound);
		}
		return response.toString();
		
	}
	
	private String convertToLowerCase(String str){
		return str.toLowerCase();
	}
	
	private String convertToUpperCase(String str){
		return str.toUpperCase();
	}
	
	private String getResponse(List<PropertyData> propertyList, String propertyListName){
		Iterator it = propertyMap.entrySet().iterator();
		StringBuilder response = new StringBuilder();
		response.append("<PropertyList><"+propertyListName+">");
		if (propertyList.size() != 0) {
			for (PropertyData property : propertyList) {
				response.append("<"+property.getPropertyKey()+">"+property.getPropertyValue()+"<"+property.getPropertyKey()+">");
			}
		}
	    response.append("</"+propertyListName+"></PropertyList>");
	    return response.toString();
	}

}
