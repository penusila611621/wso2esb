/**
 * 
 */
package com.aegbt.gtr.propertyDataService.constants;

/**
 * @author gavvaru
 *
 */
public interface PropertyDataConstants {
	public static final String invalidPosition = "Invalid position";
	public static final String noListKeyFound = "No property list / property key found";
	public static final String noListFound = "No property list found";
	public static final String noKeyFound = "No property key found";
	//public static final int schdulerTime = 86400000;
	public static final int schdulerTime = 120000;
	public static final String splitBy = "//";
	/**
	 * LOG_BEFOREMETHODEXECUTION_MESSAGE- message to log before the execution of a method.
	 */
	public String LOG_BEFOREMETHODEXECUTION_MESSAGE = "Entering: ";

	/**
	 * LOG_AFTERMETHODEXECUTION_MESSAGE- message to log after successful execution of a method.
	 */
	public String LOG_AFTERMETHODEXECUTION_MESSAGE = "Exited: ";

	/**
	 * LOG_EXCEPTION_MESSAGE- Exception message to log for the exceptions caught.
	 */
	public String LOG_EXCEPTION_MESSAGE = "Exception: ";

}
